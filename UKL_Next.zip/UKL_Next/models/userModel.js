    const bcrypt = require('bcryptjs');

    // Hash password "password123" jika belum ada
    const hash = bcrypt.hashSync('password123', 10);

    const users = [
    {
        id: 1,
        username: 'john_doe',
        password: hash, // Pastikan hash ini cocok dengan input "password123"
        role: 'Siswa',
    },
    ];

    console.log('Generated Hash:', hash); // Tambahkan ini jika perlu melihat hash
    module.exports = users;
